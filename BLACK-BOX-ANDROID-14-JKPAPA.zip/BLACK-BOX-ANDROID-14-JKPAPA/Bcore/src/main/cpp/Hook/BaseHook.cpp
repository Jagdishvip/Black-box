//
// Created by Milk on 4/10/21.
//

#include "BaseHook.h"


void BaseHook::init(JNIEnv *env) {

}
