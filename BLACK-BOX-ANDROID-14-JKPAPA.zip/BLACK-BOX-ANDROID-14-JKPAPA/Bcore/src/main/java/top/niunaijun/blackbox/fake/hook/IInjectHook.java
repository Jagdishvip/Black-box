package top.niunaijun.blackbox.fake.hook;

import java.lang.reflect.Method;

/**
 * Created by @jagdish_vip on 2/15/24.
 * * ∧＿∧
 * (`･ω･∥
 * 丶　つ０
 * しーＪ
 * 此处无Bug
 */
public interface IInjectHook {
    void injectHook();

    boolean isBadEnv();
}
