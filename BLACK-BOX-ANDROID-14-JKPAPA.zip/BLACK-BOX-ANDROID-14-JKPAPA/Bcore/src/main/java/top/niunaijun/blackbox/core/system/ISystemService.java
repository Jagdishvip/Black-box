package top.niunaijun.blackbox.core.system;

/**
 * Created by @jagdish_vip on 4/22/21.
 * * ∧＿∧
 * (`･ω･∥
 * 丶　つ０
 * しーＪ
 * 此处无Bug
 */
public interface ISystemService {
    void systemReady();
}
