package black.android.content.pm;

import top.niunaijun.blackreflection.annotation.BClassName;
import top.niunaijun.blackreflection.annotation.BStaticField;
import top.niunaijun.blackreflection.annotation.BStaticMethod;

/**
 * @author gm
 * @function
 * @date :2024/4/24 21:26
 **/
@BClassName("android.content.pm.pkg.FrameworkPackageUserState")
public interface FrameworkPackageUserState {
    @BStaticField
    Object gDefault();
}
